package ru.profiles.webapi.interfaces

import io.reactivex.Observable
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST

interface AuthApi {

    @Headers("Content-Type: application/json", "Cache-Control: no-cache")
    @POST(" /api/v1/login/")
    fun authorizeUser(
        @Body auth_request: String
    ): Observable<String>


    @Headers("Content-Type: application/json", "Cache-Control: no-cache")
    @POST(" /api/v1/delegate/")
    fun updateAuth(
    ): Observable<String>
}