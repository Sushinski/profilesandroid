package ru.profiles.webapi.builder

import retrofit2.Retrofit
import okhttp3.OkHttpClient
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.create
import ru.profiles.webapi.interfaces.AuthApi


class AuthApiBuilder private constructor(){

    companion object {
        fun buildForUrl(base_url: String): AuthApi{
            return Retrofit.Builder()
                .baseUrl(base_url)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(OkHttpClient().newBuilder().build() )
                .build().create()
        }
    }

}