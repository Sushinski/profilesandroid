package ru.profiles.di

import androidx.lifecycle.ViewModel
import dagger.Binds
import dagger.Module
import dagger.multibindings.ClassKey
import dagger.multibindings.IntoMap
import ru.profiles.viewmodel.LoginViewModel

@Module
abstract class ViewModelModule{
    @Binds
    @IntoMap
    @ClassKey(LoginViewModel::class)
    abstract fun bindUserViewModel(loginViewModel: LoginViewModel): ViewModel
}