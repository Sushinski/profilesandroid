package ru.profiles.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import ru.profiles.data.AuthRepository
import ru.profiles.data.UserRepository
import ru.profiles.model.AuthModel
import ru.profiles.model.UserModel
import javax.inject.Inject

class LoginViewModel : ViewModel() {

    val mUser: LiveData<UserModel>

    val mAuth: LiveData<AuthModel>


    @Inject
    lateinit var mUserRep: UserRepository

    @Inject
    lateinit var mAuthRep: AuthRepository

    init{
        mUser = mUserRep.getLastLoggedUser() ?: UserModel()
        mAuth = mAuthRep.getUserAuth()
    }

}
