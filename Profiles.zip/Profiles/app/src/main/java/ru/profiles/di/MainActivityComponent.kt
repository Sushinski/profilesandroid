package ru.profiles.di

import dagger.Subcomponent
import ru.profiles.profiles.MainActivity
import dagger.android.AndroidInjector



@Subcomponent(modules = [MainActivityModule::class])
interface MainActivityComponent : AndroidInjector<MainActivity>{
    @Subcomponent.Builder
    abstract class Builder : AndroidInjector.Builder<MainActivity>()
}