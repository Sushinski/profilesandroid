package ru.profiles.di

import dagger.Module
import dagger.android.ContributesAndroidInjector
import ru.profiles.ui.LoginFragment


@Module
abstract class FragmentBuilderModule {
    @ContributesAndroidInjector
    abstract fun contributeLoginFragment(): LoginFragment
}
