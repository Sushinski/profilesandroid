package ru.profiles.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import ru.profiles.dao.AuthModelDao
import ru.profiles.dao.UserModelDao
import ru.profiles.model.UserModel
import ru.profiles.worker.AppDatabaseWorker

@Database(entities = [UserModel::class], version = 1)
abstract class AppDatabase : RoomDatabase(){
    abstract fun userModelDao(): UserModelDao
    abstract fun authModelDao(): AuthModelDao

    companion object {

        @Volatile private var mInstance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return mInstance ?: synchronized(this) {
                mInstance ?: buildDatabase(context).also { mInstance = it }
            }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(context, AppDatabase::class.java, "Profiles.db")
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        val request = OneTimeWorkRequestBuilder<AppDatabaseWorker>().build()
                        WorkManager.getInstance().enqueue(request)
                    }
                })
                .build()
        }
    }
}