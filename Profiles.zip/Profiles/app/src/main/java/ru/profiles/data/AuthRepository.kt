package ru.profiles.data

import androidx.lifecycle.LiveData
import ru.profiles.dao.AuthModelDao
import ru.profiles.model.AuthModel
import ru.profiles.model.UserModel
import ru.profiles.webapi.interfaces.AuthApi
import javax.inject.Inject

class AuthRepository {

    // todo add gson converter

    @Inject
    protected lateinit var mAuthDao: AuthModelDao

    @Inject
    protected lateinit var mAuthApi: AuthApi

    init{
        // todo inject
    }

    fun getUserAuth(user: UserModel): LiveData<AuthModel> = mAuthDao.getUserAuth(user)


    fun authUser(user: UserModel){
        // todo auth user through web api
        // mAuthApi.authorizeUser(user)
    }

}