package ru.profiles.ui

import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import ru.profiles.di.Injectable
import ru.profiles.profiles.R
import ru.profiles.viewmodel.LoginViewModel
import javax.inject.Inject

class LoginFragment : Fragment(), Injectable {

    companion object {
        fun newInstance() = LoginFragment()
    }

    @Inject
    protected lateinit var viewModel: LoginViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.login_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        // todo inject this
       // viewModel = ViewModelProviders.of(this).get(LoginViewModel::class.java)
        // TODO: Use the ViewModel
        // todo check previously logged user
        /*viewModel.mUser.observe(this, user->{

        });
        // todo if none, subscribe to auth events
        viewModel.mAuth.observe(this, auth->{

        });*/
    }

}
