package ru.profiles.viewmodel

import android.arch.lifecycle.ViewModel;

class SearchViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
