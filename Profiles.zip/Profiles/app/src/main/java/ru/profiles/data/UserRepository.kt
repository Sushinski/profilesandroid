package ru.profiles.data

import androidx.lifecycle.LiveData
import ru.profiles.api.WebApi
import ru.profiles.dao.UserModelDao
import ru.profiles.model.UserModel
import javax.inject.Inject

class UserRepository {

    @Inject
    protected lateinit var mUserDao: UserModelDao

    @Inject
    protected lateinit var mWebApi: WebApi

    init{
        // todo inject
    }

    fun getLastLoggedUser() : UserModel?{
        return mUserDao.getLastLoggedUser()
    }

    fun saveUser(user: UserModel) = mUserDao.save(user)

}