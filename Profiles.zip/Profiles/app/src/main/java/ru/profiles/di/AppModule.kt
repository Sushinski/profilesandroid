package ru.profiles.di

import android.app.Application
import dagger.Module
import dagger.Provides
import ru.profiles.dao.AuthModelDao
import ru.profiles.dao.UserModelDao
import ru.profiles.data.AppDatabase
import ru.profiles.webapi.builder.AuthApiBuilder
import ru.profiles.webapi.interfaces.AuthApi
import javax.inject.Singleton

@Module(subcomponents = [MainActivityComponent::class], includes=[ViewModelModule::class])
class AppModule {

    @Singleton
    @Provides
    fun provideAuthApi(base_url: String): AuthApi {
        return AuthApiBuilder.buildForUrl(base_url)
    }

    @Singleton
    @Provides
    fun provideDb(app: Application): AppDatabase {
        return AppDatabase.getInstance(app)
    }

    @Singleton
    @Provides
    fun provideUserDao(db: AppDatabase): UserModelDao {
        return db.userModelDao()
    }

    @Singleton
    @Provides
    fun provideRepoDao(db: AppDatabase): AuthModelDao{
        return db.authModelDao()
    }
}