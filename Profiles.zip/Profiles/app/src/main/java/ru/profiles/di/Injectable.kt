package ru.profiles.di

/**
 * Injectable marker interface
 */
interface Injectable