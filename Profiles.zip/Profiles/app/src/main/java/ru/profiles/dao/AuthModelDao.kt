package ru.profiles.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import ru.profiles.model.AuthModel
import ru.profiles.model.UserModel

@Dao
interface AuthModelDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun save(auth: AuthModel)

    @Query("SELECT * FROM auth WHERE user_id = :user.id")
    fun getUserAuth(user: UserModel): LiveData<AuthModel>

    @Delete
    fun delete(auth: AuthModel)
}